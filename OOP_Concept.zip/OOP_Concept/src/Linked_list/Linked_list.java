package Linked_list;

import java.util.LinkedList;

public class Linked_list {

	public static void main(String[] args) {
		LinkedList<String> countryNames = new LinkedList<String>();

		countryNames.add("Bangladesh");
		countryNames.add("India");
		countryNames.add("Italy");
		//countryNames.addFirst("Pakistan");
		//countryNames.addLast("Russia");
		// System.out.println(countryNames);
		//countryNames.remove("India");
		//countryNames.removeAll(countryNames);
		//countryNames.removeLast();
		//countryNames.removeFirst();

		for (String country : countryNames) {
			System.out.println(country);
		}
		System.out.println("Size of the linked list:" + countryNames.size());
		System.out.println("First element:"+countryNames.getFirst());
		System.out.println("First element:"+countryNames.getLast());
	}

}
