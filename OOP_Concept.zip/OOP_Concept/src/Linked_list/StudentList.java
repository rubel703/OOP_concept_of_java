package Linked_list;
import java.util.LinkedList;
public class StudentList {
	String name, dept;
	int id,batch;
	StudentList(String name, int id, String dept, int batch){
		this.name=name;
		this.id=id;
		this.dept=dept;
		this.batch=batch;
	}
	
	public static void main(String[]args) {
		LinkedList<StudentList>list=new LinkedList<StudentList>();
		StudentList s1=new StudentList("Rubel",203,"CSE",29);
		StudentList s2=new StudentList("Shishir",201,"CSE",27);
		StudentList s3=new StudentList("Ishpita",202,"CSE",28);
		
		list.add(s1);
		list.add(s2);
		list.add(s3);
		
		for(StudentList s:list) {
			System.out.println("Name : "+s.name+"\nID   : "+s.id+"\nDept : "+s.dept+"\nBatch: "+s.batch);
			System.out.println();
		}
		
	}

}
