package constructor;

public class Student {
	int id;
	String name;
	Student(int id, String name){
		System.out.println("Hello");
		this.id=id;
		this.name=name;
	}
	
	void display() {
		System.out.println("your id="+id);
		System.out.println("your name="+name);
	}

}
