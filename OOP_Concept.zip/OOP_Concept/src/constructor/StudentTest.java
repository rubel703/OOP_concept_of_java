package constructor;

public class StudentTest {

	public static void main(String[] args) {
		Student std=new Student(203, "rubel");
		std.display();

	}

}
