package animal_2;

public class Donkey {

}
