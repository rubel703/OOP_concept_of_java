package animal_2;

public class Dog {
	public static void main(String[]args) {
		
	}

}
