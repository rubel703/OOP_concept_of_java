package toStringMethod;

public class Person {
	String name, university, qualification;
	int age;
	
	
	Person(String name, int age, String university, String qualification){
		this.name=name;
		this.age=age;
		this.university=university;
		this.qualification=qualification;
	}
	
	public String toString() {
		return "Name: "+name +"\nAge: "+age+"\nUniversity: "+university+"\nQualification: "+qualification;
	}

}
