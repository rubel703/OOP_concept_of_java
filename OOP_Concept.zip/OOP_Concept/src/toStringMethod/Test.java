package toStringMethod;

public class Test {

	public static void main(String[] args) {
		Person p = new Person("Rubel", 21, "University of South Asia","B.Sc in CSE");
		System.out.println(p);
	}

}
