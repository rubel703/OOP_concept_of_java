package interface_demo;

public class Dog implements Animal {
	public void eat() {
		System.out.println("Dog eat egg");
	}
	
	public static void main(String[]args) {
		Dog d=new Dog();
		d.eat();
	}
}
