package Downcasting;

public class Animal {
	
	void eat() {
		System.out.println("Animal is eating.");
	}
	
	void sleep() {
		System.out.println("Animal is sleeping.");
	}
	void move() {
		System.out.println("Animal is running.");
	}

}
