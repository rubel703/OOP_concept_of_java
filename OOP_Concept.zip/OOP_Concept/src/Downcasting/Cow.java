package Downcasting;

public class Cow extends Animal {
	
	@Override 
	void eat() {
		System.out.println("Cow is eating.");
		
	} 
	
	void hamba() {
		System.out.println("Cow is sound hamba hamba.");
	}

}
