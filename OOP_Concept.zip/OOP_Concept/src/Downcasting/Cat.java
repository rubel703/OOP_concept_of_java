package Downcasting;

public class Cat extends Animal {

	@Override 
	void eat() {
		System.out.println("Cat is eating.");
		
	} 
	
	void mow() {
		System.out.println("Cate sound is mow mow");
	}
}
