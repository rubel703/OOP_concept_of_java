package Downcasting;

public class Dog extends Animal {
	
	@Override 
	void eat() {
		System.out.println("Dog is eating.");
		
	} 
	
	void barking() {
		System.out.println("Dog is sound barking.");
	}

}
