
package Downcasting;

public class TestDowncasting {
	public static void main(String[] args) {
		
		/*Animal animal=new Dog();
		Dog dog=(Dog) animal;
		dog.barking();
		dog.eat();
		dog.sleep();
		dog.move();*/
		
		Animal animal=new Cow();
		if(animal instanceof Cow) {
			Cow cow=(Cow) animal;
			cow.hamba();
			cow.eat();
		}
	}
}
