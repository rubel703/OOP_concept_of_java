package animal_1;

public class Cat {
	public static void main(String[] args) {
		Dog dog = new Dog();
		animal_2.Dog dogs = new animal_2.Dog();
	}

}
