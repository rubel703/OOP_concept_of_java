package animal_1;
import animal_2.*;
public class Dog {

	public static void main(String[] args) {
		Cat cat=new Cat();
		Cow cow=new Cow();
		Donkey donkey=new Donkey();
		
	}

}
