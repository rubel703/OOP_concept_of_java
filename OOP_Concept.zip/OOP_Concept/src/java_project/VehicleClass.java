package java_project;

public abstract class VehicleClass {
	String name,category,brand,regNumber;
	VehicleClass(String name,String category, String brand,String regNumber){
		this.name=name;
		this.category=category;
		this.brand=brand;
		this.regNumber=regNumber;
	}
	abstract void vehicleClassified();

}
class Bus extends VehicleClass{
	String seat,color;
	Bus(String name,String category, String brand,String regNumber, String seat, String color){
		super(name,category,brand,regNumber);
		this.seat=seat;
		this.color=color;
	}
	void vehicleClassified() {
		String vName="Name of Vehicle: "+name;
		String vCategory="Category of Vehicle "+category;
		String vBrand="Brand of Vehicle "+brand;
		String vRegNumber="regNumber of vehicle "+regNumber;
		String vSeat="Seat of vehicle "+seat;
		String vColor="Color of vehicle "+color;
		System.out.println("Details of the vehicle\n\t"+vName+"\n\t"+vCategory+"\n\t"+vBrand+"\n\t"+vRegNumber+"\n\t"+vSeat+"\n\t"+vColor);
	}
}
class MiniBus extends Bus{
	String horn;
	MiniBus(String name,String category, String brand,String regNumber, String seat, String color,String horn){
		super(name,category,brand,regNumber,seat,color);
		this.horn=horn;
	}
	void vehicleClassified() {
		String vName="Name of Vehicle: "+name;
		String vCategory="Category of Vehicle "+category;
		String vBrand="Brand of Vehicle "+brand;
		String vRegNumber="regNumber of vehicle "+regNumber;
		String vSeat="Seat of vehicle "+seat;
		String vColor="Color of vehicle "+color;
		String vHorn="Horn of Vehicle "+horn;
		System.out.println("Details of the vehicle\n\t"+vName+"\n\t"+vCategory+"\n\t"+vBrand+"\n\t"+vRegNumber+"\n\t"+vSeat+"\n\t"+vColor+"\n\t"+vHorn);
	}
}
