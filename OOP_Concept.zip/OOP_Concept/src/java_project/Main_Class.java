package java_project;

public class Main_Class {

	public static void main(String[] args) {
		
		Bus bus=new Bus("Bus","Heavy","Volvo","Dhaka B1570","48","Black");
		bus.vehicleClassified();
		
		MiniBus minibus=new MiniBus("MiniBus","MiniHeavy","TATA","Dhaka A1670","20","Red","Bow Bow");
		minibus.vehicleClassified();
	}

}
