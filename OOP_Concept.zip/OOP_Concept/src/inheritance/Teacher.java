package inheritance;

public class Teacher extends Person {

	String qualification;

	void displayinfo2() {
		displayinfo();
		//System.out.println("MY name is:" + name);
		//System.out.println("My age:" + age);
		System.out.println("My qualification:" + qualification);
	}

	public static void main(String[] args) {
		Teacher t1 = new Teacher();
		t1.name = "Rubel";
		t1.age = 21;
		t1.qualification = "B.Sc in CSE";

		t1.displayinfo2();
	}

}
