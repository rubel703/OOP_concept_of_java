package inheritance;

public class Teacher1 extends Person1 {

	private String universityname;

	public String getUniversityname() {
		return universityname;
	}

	public void setUniversityname(String universityname) {
		this.universityname = universityname;
	}

	void displayInfo() {
		System.out.println(getName());
		System.out.println(getAge());
		System.out.println(getQualification());
		System.out.println(getUniversityname());
	}

	public static void main(String[] args) {
		Teacher1 t1 = new Teacher1();
		t1.setName("Hossain Rubel");
		t1.setAge(21);
		t1.setQualification("Bsc in CSE");
		t1.setUniversityname("University of South Asia");
		t1.displayInfo();
	}

}
