/* 
 what is inheritance?
 inheritance can be defined as the process where one class acquires the properties of another.
 why do we need inheritance?
 1.for code reusability.
 2.for method overriding.
 3.to implement parent-child relationship.
 */
package inheritance;

public class Person {
	String name;
	int age;

	void displayinfo() {
		System.out.println("Name: " + name);
		System.out.println("Age: " + age);
	}

}
