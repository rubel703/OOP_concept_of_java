package inheritance;

public class Person1 {
	private String name;
	private int age;
	private String qualification1;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public String getQualification() {
		return qualification1;
	}

	public void setQualification(String qualification) {
		this.qualification1 = qualification;
	}

}
