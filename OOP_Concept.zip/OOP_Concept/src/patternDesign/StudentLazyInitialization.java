package patternDesign;

public class StudentLazyInitialization {
	int m=30;
	/*
	 * Thread safe Lazy Initialization.........
	 
	  private static StudentLazyInitialization LazyInitialization ; 
	  private StudentLazyInitialization() {
	  
	  }
	 
	 public static synchronized StudentLazyInitialization getStudentLazyInstance(){
	  if(LazyInitialization==null) {
	 LazyInitialization=new StudentLazyInitialization();
	  } 
	 return LazyInitialization;
	  }
	 */

	// double check locking principle
	private static StudentLazyInitialization LazyInitialization;

	private StudentLazyInitialization() {

	}

	public static StudentLazyInitialization getThreadSafeInstance() {
		if (LazyInitialization == null) {
			synchronized (StudentLazyInitialization.class) {
				if(LazyInitialization==null) {
					LazyInitialization=new StudentLazyInitialization();
				}
			}

		}

		return LazyInitialization;
	}
	
	public static void main(String[] args) {
		StudentLazyInitialization obj= StudentLazyInitialization.getThreadSafeInstance();
		System.out.println(obj.m);
	}
}
