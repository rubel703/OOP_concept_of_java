package patternDesign;

public class StudentTest {

	public static void main(String[] args) {
	Student s = new Student();
	System.out.println(s.getStudentInstance());
	System.out.println(s.x);

	}

}
