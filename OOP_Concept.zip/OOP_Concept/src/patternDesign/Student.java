package patternDesign;

public class Student {
	int x=100;
	
	private static final Student STUDENT_OBJ=new Student();
	Student(){
		
	}
	
	public static Student getStudentInstance(){
		return STUDENT_OBJ;
	}
	

}
