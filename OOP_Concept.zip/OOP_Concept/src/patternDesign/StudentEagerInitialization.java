package patternDesign;

public class StudentEagerInitialization {
	int x = 500;

	private static StudentEagerInitialization Student_Obj;

	private StudentEagerInitialization() {

	}
	static 
	{
		try {
			Student_Obj=new StudentEagerInitialization();
		}
		catch(Exception e) {
			throw new RuntimeException("Runtime error occrud creating instance");
		}
	}

	public static StudentEagerInitialization getStudentInstance() {
		return Student_Obj;


	}
	
	
	public static void main(String[] args) {
		StudentEagerInitialization s1=StudentEagerInitialization.getStudentInstance();
		System.out.println(s1.x);
	}
}
