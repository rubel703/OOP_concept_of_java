package encapsulatio_2;

import java.util.Scanner;

public class Employee {

	private String employeeName;
	private long account;
	private String email;
	private double balance;

	public String getEmployeeName() {
		System.out.print("Employeer Name: ");
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public long getAccount() {
		System.out.print("Employeer Account Number: ");
		return account;
	}

	public void setAccount(long account) {
		this.account = account;
	}

	public String getEmail() {
		System.out.print("Employeer Email: ");
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getBalance() {
		// System.out.println("Employeer Account Balane: "+balance);
		System.out.print("\nPlease your Account name:");
		Scanner sc = new Scanner(System.in);
		String user_name = sc.nextLine();

		System.out.print("Please your Account number:");
		Long ac_num = sc.nextLong();

		if (user_name.equals(employeeName) && ac_num == account) {
			System.out.print("\nYour Current Balance is= " + balance + "Taka");
		} else
			System.out.println(
					"Wrong user name and account name! \nPlease again your right user name and account number");
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
	
	

	public static void main(String[] args) {
		Employee e1 = new Employee();
		e1.setEmployeeName("Hossain Rubel");
		e1.setAccount(104500120);
		e1.setEmail("hossainrubel@email.com");
		e1.setBalance(5000);
		System.out.println(e1.getEmployeeName());
		System.out.println(e1.getAccount());
		System.out.println(e1.getEmail());
		// System.out.println(e1.getBalance());
		e1.getBalance();

	}

}
