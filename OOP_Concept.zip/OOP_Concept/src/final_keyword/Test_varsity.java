package final_keyword;

public class Test_varsity {

	public static void main(String[] args) {
		Varsity v=new Varsity();
		v.display();

	}

}
