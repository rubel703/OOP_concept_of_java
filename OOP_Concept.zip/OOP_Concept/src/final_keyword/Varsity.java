package final_keyword;

public class Varsity {
	final String UniversityName = "University of South Asia";
	// final int fees;
	static final int fees;// blank final variable

	/*
	 Varsity() {
	  fees = 21000;  //constructor fees 
	   * }
	 */
	static {
		fees = 21000;
	}

	void display() {
		System.out.println("University name: " + UniversityName);
		System.out.println("Tution fees= " + fees);
	}

}