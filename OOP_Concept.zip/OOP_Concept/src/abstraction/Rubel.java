package abstraction;

public class Rubel extends MobileUser {
	void Sendmessage() {
		System.out.println("Hello, i am a Rubel");
	}

}
