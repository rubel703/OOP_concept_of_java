package abstraction;

abstract public class MobileUser {  //abstract class
	abstract void Sendmessage();//abstract method
	
	void call() {  //non-abstract method
		System.out.println("Call me"); 
	}
}
