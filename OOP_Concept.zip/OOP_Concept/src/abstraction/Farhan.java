package abstraction;

public class Farhan extends MobileUser {
	void Sendmessage() {
		System.out.println("Hi, I am a farhan");
	}

	public static void main(String[] args) {
		MobileUser m; // reference variable
		m = new Rubel();
		m.Sendmessage();
		m.call();

		m = new Farhan();
		m.Sendmessage();
		m.call();

	}

}
