package this_keyword_2;

public class StudentTest {

	public static void main(String[] args) {
		Student s1=new Student(2030032006, "Rubel", "Noakhali", 22);
		s1.dispaly();
		Student s2=new Student(2030087006, "Delware", "Cumilla", 23, 1000.0);
		s2.dispaly2();

	}

}
