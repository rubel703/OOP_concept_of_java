package this_keyword_2;

public class ABC {
	
	void m1()
	{
		System.out.println("this method");
	}
	
	void n1()
	{
		this.m1();  //used this keyword called by m1 method
	}
	
	public static void main(String[] args) {
		ABC abc=new ABC();
		abc.n1();
	}

}
