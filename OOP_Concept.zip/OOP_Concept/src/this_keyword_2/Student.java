package this_keyword_2;

public class Student {

	/*
	 * Student(){ System.out.println("hello java programmer"); }
	 * 
	 * Student(int a){ this(); //current class constructor called used by this
	 * keyword }
	 * 
	 * public static void main(String[] args) { Student s1=new Student(5);
	 * 
	 * }
	 */

	int id;
	String name;
	String address;
	int age;
	double fee;

	Student(int id, String name, String address, int age) {
		this.id = id;
		this.name = name;
		this.address = address;
		this.age = age ;
	}
	
	
	
	Student(int id, String name, String address, int age, double fee) {
		//this.id = id;
		//this.name = name;
		//this.address = address;
		//this.age = age;
		this(id, name, address, age);
		this.fee = fee;
	}




	void dispaly() {
		System.out.println("\nID: "+id+"\nName: "+name+"\nAddress: "+address+"\nAge: "+age);
	}
	void dispaly2() {
		System.out.println("\nID: "+id+"\nName: "+name+"\nAddress: "+address+"\nAge: "+age+"\nFees: "+fee);
	}

}