package method_hiding;

public class ParentClass {
	public static void classMethod() {
		System.out.println("class method in parent class.");
	}
	void instanceMethod() {
		System.out.println("instance method in parent class.");
	}

}
