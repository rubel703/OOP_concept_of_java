package method_hiding;

public class ChildClass extends ParentClass {
	public static void classMethod() {
		System.out.println("class method in child class.");
	}
	public void instanceMethod() {
		System.out.println("instance method in child class.");
	}
	
	
	
	public static void main(String[] args) {
		ParentClass pc=new ChildClass();
		pc.classMethod();  //calling with reference(method hiding) 
		pc.instanceMethod(); //calling with object(method overriding)
		
		ParentClass pc1=new ParentClass();
		pc1.classMethod(); //calling with reference 
		pc1.instanceMethod(); //calling with object
		
		ChildClass c=new ChildClass();
		c.classMethod(); //calling with reference
		c.instanceMethod(); //calling with object
	}

}
