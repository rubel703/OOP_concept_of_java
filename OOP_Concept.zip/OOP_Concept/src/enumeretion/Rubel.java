package enumeretion;

public class Rubel {
	void displayInfo() {
		System.out.println("Hi, I am a Rubel");
	}

}
