package enumeretion;

public class Test {

	public static void main(String[] args) {
		Rubel r = new Rubel() { //object class
			void displayInfo() {  //override method
				System.out.println("hi, i am rubel");
			}
		};
		r.displayInfo();

	}

}
