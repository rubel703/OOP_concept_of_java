package instance_Operator;

public class Test_of_3class {
	public static void main(String[] args) {
		Animal a = new Animal();
		Person p = new Person();
		Student s = new Student();
		
		System.out.println(a instanceof Animal);
		System.out.println(p instanceof Animal);
		System.out.println(s instanceof Person);
		System.out.println(s instanceof Animal);
		System.out.println(p instanceof Student);
		System.out.println(a instanceof Student);
	}

}
