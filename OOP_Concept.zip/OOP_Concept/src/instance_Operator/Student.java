package instance_Operator;

public class Student extends Person{

}
