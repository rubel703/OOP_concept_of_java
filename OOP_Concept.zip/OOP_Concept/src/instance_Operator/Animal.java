package instance_Operator;

public class Animal {

}
