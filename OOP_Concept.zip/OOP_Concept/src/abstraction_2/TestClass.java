package abstraction_2;

public class TestClass {
	public static void main(String[] args) {
		Shape s=new Circle();
		s.draw();
		s.calculateArea();
		
		s=new Rectangle();
		s.draw();
	}
}
