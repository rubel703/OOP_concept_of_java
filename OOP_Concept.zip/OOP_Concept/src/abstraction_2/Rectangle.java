package abstraction_2;

public class Rectangle extends Shape {

	@Override
	void draw() {
		System.out.println("Drawing rectangle.");
	}

	@Override
	void calculateArea() {
		
		
	}

}
