package abstraction_2;

public abstract class Shape {
	
	abstract void draw();
	
	abstract void calculateArea();

}
