package abstraction_2;

public class Circle extends Shape {

	@Override
	void draw() {
		System.out.println("Drawing circle.");
	}

	@Override
	void calculateArea() {
		
		double r=3;
		double Pi=3.1416;
		double area;
		
		area=Pi*(r*r);
		System.out.printf("calculate of circle area=%.2f \n",area);
		
		
	}

}
