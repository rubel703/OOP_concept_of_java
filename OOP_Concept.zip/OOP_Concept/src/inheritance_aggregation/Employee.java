package inheritance_aggregation;

public class Employee {
	
	int id;
	String name;
	Address address;  //Aggregation/Composition/Has A relationship
	
	public Employee(int id, String name, Address address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}
	
	void display() {
		
		System.out.println("Id: "+id+"\nName: "+name);
		System.out.println("City: "+address.getCity()+"\nDivision: "+address.getDivision()+"\nCountry: "+address.getCountry());
	}
	
	public static void main(String[] args) {
		
		Address a1=new Address("Dhaka", "Noakhali", "Bangladesh");
		Employee e1=new Employee(203, "Rubel", a1);
		e1.display();
	}
	

}
