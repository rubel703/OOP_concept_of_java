package inheritance_aggregation;

public class Address {
	
	String city, division,  country;

	
	public Address(String city, String division, String country) {
		this.city = city;
		this.division=division;
		this.country=country;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getDivision() {
		return division;
	}


	public void setDivision(String division) {
		this.division = division;
	}
	
	
}
