package classes;

public class Teacher //parent class or super class
	{
		String name,gender; int phone;
	    void displayInformation() //display method
	{    
		System.out.println("Teacher name: "+name);
		System.out.println("Teacher gender: "+gender);
		System.out.println("Teacher phone number: "+phone);
		System.out.println();
	}


	public static void main(String[] args) 
		{
		 		Teacher teacher1=new Teacher();  //object declared  
				teacher1.name="Hossain Rubel";  //1st object 
				teacher1.gender="Male";
				teacher1.phone= 1824089282;
				teacher1.displayInformation();
				
				/*System.out.println("Teacher name: "+teacher1.name);
				System.out.println("Teacher gender: "+teacher1.gender);
				System.out.println("Teacher phone number: "+teacher1.phone);*/
				System.out.println();
				
				Teacher teacher2=new Teacher();
				teacher2.name="Hena";  //2nd object
				teacher2.gender="female";
				teacher2.phone=1875908295;
				teacher2.displayInformation();
				
				/*System.out.println("Teacher name: "+teacher2.name);
				System.out.println("Teacher gender: "+teacher2.gender);
				System.out.println("Teacher phone number: "+teacher2.phone);*/
	}
}
		

