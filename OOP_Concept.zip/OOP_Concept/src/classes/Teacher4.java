//sub: overloading constructor

/*Difference between constructor and method.
 constructor: constructor is used to initialized the state of an object.
 method: method to used to expose behavior of an object.
 constructor: constructor must not have return type.
 method: method must have return type.
 constructor: constructor must have same name the class name.
 method: method should not same name the class name.  
 */
package classes;

public class Teacher4 
	{
	String name,gender; int phone;
	
	Teacher4(){
		System.out.println("NO Information");
	}
	
	Teacher4(String n,String g)
	{
		name=n;gender=g;
		
	}
	Teacher4(String n,String g,int p)
	{
		name=n;gender=g;phone=p;
		
	}
	
	void displayInformation() 
	{
		System.out.println("Name:"+name);
		System.out.println("Gender:"+gender);
		System.out.println("Phone:"+phone);
		System.out.println();
	}
	
	public static void main(String[]args) {
		Teacher4 teacher1=new Teacher4();
		
		Teacher4 teacher2=new Teacher4("Aksar pattel","Male");
		teacher2.displayInformation();
		
		Teacher4 teacher3=new Teacher4("Manish penday","Male", 1823679201);
		teacher3.displayInformation();
	}

}
