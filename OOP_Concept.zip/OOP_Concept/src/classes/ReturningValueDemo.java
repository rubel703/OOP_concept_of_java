//Sub: returning a value from method

package classes;
public class ReturningValueDemo {
	int square (int value) {
		return value*value;
	}
	
	public static void main(String[]args) {
		ReturningValueDemo obj1=new ReturningValueDemo();
		ReturningValueDemo obj2=new ReturningValueDemo();
		//int result=obj1.square(5);
		//System.out.println(result);
		System.out.println("Square of:"+obj1.square(9));
		System.out.println("Square of:"+obj2.square(11));
	}

}
