package classes;

public class Teacher3  //super class
	{ 
	String name,gender; int phone;
	
	
	/*Constructor method: constructor has the same as the class it belongs.
	  it has no return type not even void. it has called automatically. */
		Teacher3(String n,String g,int p) // perameter constructor method
	{
		name=n;
		gender=g;
		phone=p;
		
	}
		Teacher3()  //Default constructor method
		{
			System.out.println("NO value");
		}
		
	void displayInformation()   //display method
	{ 
		System.out.println("Teacher name: "+name);
		System.out.println("Teacher gender: "+gender);
		System.out.println("Teacher phone number: "+phone);
		System.out.println();
	}

		public static void main(String[] args)   //main method
		{  
			Teacher3 teacher1=new Teacher3("Hossain Rubel", "male", 1721267791);
			teacher1.displayInformation();
			
			Teacher3 teacher2=new Teacher3("Sharmin", "female", 1621267751);
			teacher2.displayInformation();
			
			Teacher3 teacher3=new Teacher3();
			teacher3.displayInformation();

		}

		}
