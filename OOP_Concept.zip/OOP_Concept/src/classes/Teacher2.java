package classes;

public class Teacher2
	{
	String name,gender; int phone;
	
	 void setInformation(String n,String m,int ph)  //setInformation method
	 {
		name=n;
		gender=m;
		phone=ph;
	 }
	void displayInformation() 
	{
		System.out.println("Teacher name: "+name);
		System.out.println("Teacher gender: "+gender);
		System.out.println("Teacher phone number: "+phone);
		System.out.println();
	}

		public static void main(String[] args)
		{
			Teacher2 teacher1=new Teacher2();
			teacher1.setInformation("Hossain Rubel", "male", 1721267791);
			teacher1.displayInformation();
			
			Teacher2 teacher2=new Teacher2();
			teacher2.setInformation("Farhana", "female", 1721267751);
			teacher2.displayInformation();

		}

		}

