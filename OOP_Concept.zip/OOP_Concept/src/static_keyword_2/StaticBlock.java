package static_keyword_2;

public class StaticBlock {
	static int x=m1();   //static variable
	
	static     //static block
	{
		System.out.println("this is static block");
	}
	
	static int m1()   //static method
	{
		System.out.println("this is static method");
		return 10;
	}
	
	public static void main(String[] args) {
		System.out.println("this is main method");
		System.out.println("value of X="+x);
	}

}
