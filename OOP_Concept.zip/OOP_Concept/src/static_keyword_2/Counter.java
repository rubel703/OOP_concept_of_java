package static_keyword_2;

public class Counter {
	//int count=0;
	static int count=0;
	
	Counter(){
		count++;
	}
	
	void getCount() {
		System.out.println("The values of count is="+count);
	}
	
	public static void main(String[] args) {
		Counter c1=new Counter();
		c1.getCount();
		Counter c2=new Counter();
		c2.getCount();
		Counter c3=new Counter();
		c3.getCount();
	}
}
