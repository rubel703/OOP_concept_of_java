package static_keyword_2;

public class Employee {
	int id;
	String name;
	static String companyName="Unilever";

	Employee(int id, String name) {
		this.id=id;
		this.name=name;

	}
	
	//void setCompanyName(String companyName)
	static void setCompanyName(String companyName)
	{ 
		Employee.companyName=companyName;
		//this.companyName=companyName;
	}
	
	void displayInfo() {
		System.out.println("ID:"+id+", Name:"+name+", Company name:"+companyName);
	}
}
