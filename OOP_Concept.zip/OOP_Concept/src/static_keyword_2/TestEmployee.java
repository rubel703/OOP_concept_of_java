package static_keyword_2;

public class TestEmployee {

	public static void main(String[] args) {
		Employee e1=new Employee(101, "rubel");
		Employee e2=new Employee(103, "hasan");
		e1.displayInfo();
		e2.displayInfo();
		
		//e1.setCompanyName("Unilever Group");  //company name change 
		Employee.setCompanyName("Unilever Group");
		
		Employee e3=new Employee(102, "farhan");
		e3.displayInfo();
		Employee e4=new Employee(105, "Maysiha");
		e4.displayInfo();
		
		
	}

}
