package static_keyword_2;

public class StaticInnerOuter {
	static int x=10;
	
	static class Inner{
		//void msg()
		static void msg()
		{
			System.out.println(x);
		}
	}

	public static void main(String[] args) {
		
		//StaticInnerOuter.Inner inner=new StaticInnerOuter.Inner();
		//inner.msg();
		StaticInnerOuter.Inner.msg();
	}

}
