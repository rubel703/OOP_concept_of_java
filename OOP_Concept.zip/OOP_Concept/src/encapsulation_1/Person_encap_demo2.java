package encapsulation_1;

public class Person_encap_demo2 {
	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age=age;
	}
	public int getAge() {
		return age;
	}

	public static class Encapsulation {
		public static void main(String[] args) {
			Person_encap_demo2 p1 = new Person_encap_demo2();
			p1.setName("Rubel");
			System.out.println(p1.getName());
			p1.setAge(21);
			System.out.println(p1.getAge());
		}
	}

}
