package encapsulation_1;

public class EncapsulationDemo {
/*
  Access modifier keyword.
  1.private
  2.public
  3.protected
  4.default
  Encapsulation is a process of 
  1.packaging variable and methods into a single unit.
  2.protecting data by declaring them as private.
  How to do encapsulation?
  1.declare the variable as private.
  2.provide public setter and getter method to modifier and get the variable value.
 */
}
