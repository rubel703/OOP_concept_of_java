package polymorphism;

public class Rectangle extends Shape {
	double lenght, width;

	Rectangle(double lenght, double width) {
		this.lenght = lenght;
		this.width = width;
	}

	double area() {
		return lenght * width;

	}

}
