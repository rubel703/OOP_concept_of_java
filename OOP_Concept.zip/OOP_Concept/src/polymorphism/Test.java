package polymorphism;

public class Test {

	public static void main(String[] args) {
		Person p=new Person();
		p.display();
		//Teacher t=new Teacher();    //overriding polymorphism method
		p=new Teacher();
		p.display();
		//Student s=new Student();
		p=new Student();
		p.display();
	}

}
