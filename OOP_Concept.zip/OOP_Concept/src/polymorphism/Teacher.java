package polymorphism;

public class Teacher extends Person {
	void display() {
		System.out.println("This method is teacher");
	}

}
