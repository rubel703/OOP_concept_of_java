package polymorphism;

public class Student extends Person{
	void display() {
		System.out.println("This method is student");
	}

}
