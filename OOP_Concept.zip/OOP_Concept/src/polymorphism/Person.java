package polymorphism;

public class Person {
	void display() {
		System.out.println("This method is person");
	}

}
