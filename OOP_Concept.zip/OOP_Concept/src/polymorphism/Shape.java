package polymorphism;

public class Shape {
	double area() {
		return 0;
	}

}
