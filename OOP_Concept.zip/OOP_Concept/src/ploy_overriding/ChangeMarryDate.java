package ploy_overriding;

public class ChangeMarryDate extends Marry {
	
	@Override
	public void marryDate()  //overriding   method
	{
		System.out.println("Previous marred date was 26 january.");
		System.out.println("Change Marry date will be done 30 january.");
	}

}
