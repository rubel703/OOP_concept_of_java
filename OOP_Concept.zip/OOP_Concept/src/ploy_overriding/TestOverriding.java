package ploy_overriding;

public class TestOverriding {
	
	public static void main(String[] args) {
		
		Marry marry = new Marry();
		marry.engagementDate();
		//marry.marryDate();
		ChangeMarryDate changemarry=new ChangeMarryDate();
		changemarry.marryDate();
	}

}
