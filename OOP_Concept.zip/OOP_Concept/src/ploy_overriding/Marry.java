package ploy_overriding;

public class Marry {

	void engagementDate() {
		System.out.println("Engagement will be done 22 january.\n");
	}
	
	protected void marryDate() {  //overridden method
		System.out.println("Marry will be done 26 january.");
	}
	
}
