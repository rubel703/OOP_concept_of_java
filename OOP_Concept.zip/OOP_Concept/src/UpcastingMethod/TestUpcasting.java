
package UpcastingMethod;

public class TestUpcasting {

	public static void main(String[] args) {
		
		/*Animal animal=new Animal();
		Dog dog=new Dog();
		animal=dog;
		Animal animal2=new Dog();*/
		
		Animal a;
		a=new Dog();
		Animal a1=new Dog();
		a.eat();
		a.move();
		a.sleep();
		
		a=new Cat();
		a.eat();
		
		a=new Cow();
		a.eat();
	}

}
