package Interface;

public interface B extends C {
	int b=20;
	void m2();

}
