package Interface;

public interface C {
	int c=30;
	
	void m3();

}
