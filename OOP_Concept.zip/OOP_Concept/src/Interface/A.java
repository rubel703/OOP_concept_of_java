package Interface;

public interface A {
	int a=10;
	
	void m1();

}
