package Interface;

public class ChildImple extends Implementation  {

	@Override
	public void m1() {
		System.out.println("This method is m1 for A interface its value of: "+a);
		
	}

	@Override
	public void m2() {
	System.out.println("this method is m2 for B interface its value of: "+b);
		
	}

	@Override
	public void m3() {
		System.out.println("this method is m3 for interface its value of: "+c);
		
	}
	
	
	public static void main(String[] args) {
		ChildImple ci = new ChildImple();
		ci.m1();ci.m2();ci.m3();
	}

}
