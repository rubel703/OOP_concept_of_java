package Interface;

public interface area {
	double pi=3.1416;
	
	double calculatorArea(double a, double b);

}
