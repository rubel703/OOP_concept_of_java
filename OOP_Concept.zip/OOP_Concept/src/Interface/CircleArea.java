package Interface;

public class CircleArea implements area{

	@Override
	public double calculatorArea(double a, double b) {
	double circleOfArea= pi*a*b;
		return circleOfArea;
	}
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		area a;
		a=new CircleArea();
		System.out.println(a.calculatorArea(3, 4));
		
		a=new Square();
		System.out.println(a.calculatorArea(3, 4));
	}


	

}
