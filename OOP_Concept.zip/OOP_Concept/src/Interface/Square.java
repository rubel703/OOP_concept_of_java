package Interface;

public class Square implements area {

	@Override
	public double calculatorArea(double a, double b) {
		double sqr=a*b;
		return sqr;
	}

}
