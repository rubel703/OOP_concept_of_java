package Interface;

public abstract class Implementation implements A, B {
	

}
