//used of Static variable

package static_keyword_1;
public class Student {
	String name;
	int id;
	static String universityName="University of South Asia";
	
	Student(String n,int i){
		name=n;
		id=i;
	}
	
	void displayInfo() {
		System.out.println("Student Name:"+name);
		System.out.println("Student ID:"+id);
		System.out.println("University Name:"+universityName);
		System.out.println();
	}
	
	public static void main(String[]args) {
		Student s1=new Student("Rubel",203);
		Student s2=new Student("Hossain",201);
		s1.displayInfo();
		s2.displayInfo();
	}

}
