//Static block method

package static_keyword_1;

	public class Static_block {
	static String name;
	static int ID;
	
	static {
		ID=203;
		name="Rubel";
	}
	static void display() {
		System.out.println(ID);
		System.out.println(name);
	}
	
	public static class Test{
	public static void main(String[]args) {
		Static_block.display();
	}
}

}
