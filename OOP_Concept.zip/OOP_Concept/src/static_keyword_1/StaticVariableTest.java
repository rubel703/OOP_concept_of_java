package static_keyword_1;

public class StaticVariableTest {
	public static void main(String[]args) {
		//StaticVariable obj=new StaticVariable();
		System.out.println("Varsity Name:"+StaticVariable.universityName);
	}

}
