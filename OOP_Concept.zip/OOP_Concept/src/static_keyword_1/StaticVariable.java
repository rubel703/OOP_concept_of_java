package static_keyword_1;

public class StaticVariable {
	//String universityName="University of South Asia";
	static String universityName="University of South Asia";

}
