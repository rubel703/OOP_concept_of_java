/*Static method.
//non-static method print korte object create korte hoy 
//and static method print korte obj dorker nai just class name dot sign static method dile hobe.
Non static method and static method. Static method not an access non static method.*/
package static_keyword_1;

public class Static_Method {
	void display() {
		System.out.println("I am non static method");
	}
	static void display2() {
		System.out.println("I am a static method");
	}
	
public static class Test{
		public static void main(String[]args) {
			Static_Method obj1=new Static_Method();
			obj1.display();
			
			Static_Method.display2();
		}
		
	}
	 

}
