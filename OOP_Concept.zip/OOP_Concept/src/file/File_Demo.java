/*
 1.How to create folder/directory,file.
 2.How to write into a file.
 3.How to read into a file.
 */


package file;

import java.io.File;

public class File_Demo {
	public static void main(String[]args) {
		//How to create folder or directory.
		File dir=new File("person");
		dir.mkdir();  //directory will created.
		/*String location=dir.getAbsolutePath(); //directory or folder location
		System.out.println(location);
		System.out.println(dir.getName());
		/*if(dir.delete()) {  //folder delete
			System.out.println("Folder has been deleted:"+dir.getName());
		}*/
		
		//How to create file. 
		String location=dir.getAbsolutePath();
		System.out.println(location);
		File file=new File(location+"/Student.text");
		try {
			file.createNewFile();
			System.out.println("File is a created");
		}catch(Exception e)
		{
			System.out.println(e);
		}
		//file.delete();
		if(file.exists()) {
			System.out.println("File has exists");
		}
		else
			System.out.println("File does not exists");
	}

}
