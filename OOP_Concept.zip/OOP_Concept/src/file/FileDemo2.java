package file;

import java.util.Formatter;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class FileDemo2 {

	public static void main(String[] args) {
		String id, name;
		int i, num;
		try {
			Formatter f = new Formatter(
					"C:/Users/LENOVO/eclipse-workspace/Object_Oriented_project/person/Student.text");
			Scanner input = new Scanner(System.in);
			System.out.print("How many Students=");
			num = input.nextInt();
			for (i = 1; i <= num; i++) {
				System.out.print("Enter Students ID and Name=");
				id = input.next();
				name = input.next();
				f.format("%s %s\r\n",id, name);
			}
			f.close();
			System.out.println("Write success!");
		} catch (FileNotFoundException e) {
			System.out.println(e);

		}

	}

}
