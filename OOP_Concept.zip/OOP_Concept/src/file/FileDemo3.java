package file;

import java.io.File;
import java.util.Scanner;
public class FileDemo3 {

	public static void main(String[] args) {
		try
		{           //file read
			File file=new File("C:/Users/LENOVO/eclipse-workspace/Object_Oriented_project/person/Student.text");
			Scanner s=new Scanner(file);
			while(s.hasNext()) {
				String id=s.next();
				String name=s.next();
				System.out.printf("\nID:"+id +", Name:"+name);
			}
			s.close();
		}
		catch(Exception e) 
		{
			System.out.println(e);
		}
		
	
	}
}
