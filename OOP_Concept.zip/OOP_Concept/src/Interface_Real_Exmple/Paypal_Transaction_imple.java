package Interface_Real_Exmple;

public class Paypal_Transaction_imple implements Paypal  {
	
	@Override
	public void rocketPayment(double paybal_amount) {
		System.out.println("Payment is successsful done by Rocket=" +paybal_amount +"$");
	}
	
	@Override
	public void bkashPayment(double paybal_amount) {
		System.out.println("Payment is successsful done by Bkash=" +paybal_amount +"$");
	}
	
	@Override
	public void nexusPayment(double paybal_amount) {
		System.out.println("Payment is successsful done by Nexus=" +paybal_amount +"$");
	}

}
