package Interface_Real_Exmple;

public interface Paypal {
	
	void rocketPayment(double paybal_amount);
	void bkashPayment(double paybal_amount);
	void nexusPayment(double paybal_amount);

}
