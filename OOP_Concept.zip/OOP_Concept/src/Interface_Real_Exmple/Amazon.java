package Interface_Real_Exmple;

public class Amazon {
	public static void main(String[] args) {

		Paypal paymentMethod;
		paymentMethod=new Paypal_Transaction_imple();
		
		paymentMethod.bkashPayment(300);
	}

}
