package another_discussion;
//method overloading or polymorphism 
public class OverLoad {
	void add(int a, int b){
		System.out.println(a+b);
	}
	void add(double a, double b){
		System.out.println(a+b);
	}
	void add(int a, int b, int c){
		System.out.println(a+b);
	}
	void add(){
		System.out.println("Nothing to add");
	}
	void add(int a, double d) {
		System.out.println(a-d);
	}
	
	public static void main(String[]args) {
		OverLoad x=new OverLoad();
		x.add();
		x.add(5.6, 8.8);
		x.add(12, 8);
		x.add(10, 20, 30);
		x.add(30, 20);
	}

}
