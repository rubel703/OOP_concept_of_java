//variable arguments length method

package another_discussion;

public class Vari_Argu_Lenght {
	void add(int... num) { // variable arguments length
		int sum = 0;
		for (int x : num) {
			sum = sum + x;
		}
		System.out.println(sum);
	}

	public static void main(String[] args) {
		Vari_Argu_Lenght ob1 = new Vari_Argu_Lenght();
		ob1.add(10, 20, 30);
		ob1.add(10, 20, 30, 50);

	}

}
