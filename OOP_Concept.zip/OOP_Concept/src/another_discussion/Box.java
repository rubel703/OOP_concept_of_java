/*
 problem 1:
 Create a class called box that include three pieces of information as instance variable-height, width, depth(type double)
 of two boxes. your class should have a constructor and initialize the three instance variables.
 provided a method displayVol that display the volume of two boxes. suppose the values of instance variable for the first box are(10,10,10)
 and second box(20,30,10). write a test application named BoxVolume that demonstrate class Box's capabilities.
 */
package another_discussion;

public class Box {
	double height,width,depth;  //instance variable
	
	Box(double h, double w, double d){
		height=h;  //Local variable
		width=w;
		depth=d;
	}
	
	void displayVol() {
		double vol=height * width * depth;
		System.out.println("Volume is:"+vol);
	}
}
