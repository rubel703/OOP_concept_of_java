//Instance variable Hiding method discussion...........

package another_discussion;

public class InstanceVariableHiding {
	double height, width, depth; // instance variable

	InstanceVariableHiding(double height, double width, double depth) {
		this.height = height; // instance variable=local variable
		this.width = width;
		this.depth = depth;
	}

	void displayVol() {
		double vol = height * width * depth;
		System.out.println("Volume is:" + vol);
	}

	public static class InstanceVariableHiding2 {
		public static void main(String[] args) {
			Box box1 = new Box(10, 20, 10);
			Box box2 = new Box(20, 30, 10);

			box1.displayVol();
			box2.displayVol();
		}

	}

}
