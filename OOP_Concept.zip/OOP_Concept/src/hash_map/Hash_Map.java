package hash_map;

import java.util.HashMap;

public class Hash_Map {
	public static void main(String[]args) {
		HashMap<Integer,String>customer=new HashMap<Integer,String>();
		customer.put(203,"Rubel");
		customer.put(101,"Hena");
		System.out.println(customer.get(203));
	}

}
