package this_keyword;
/* 1.refer current class instance variable.
   2.it can be used to call current class constructor.*/

public class Person {
	String name;
	int age;
	String hairColor;

	Person(String name, int age) { // 1st constructor
		this.name = name;
		this.age = age;
	}

	Person(String name, int age, String hairColor) { // 2nd constructor
		this(name, age);
		this.hairColor = hairColor;
	}

	void display() {
		System.out.println(name);
		System.out.println(age);
		System.out.println(hairColor);
		System.out.println();
	}

}
