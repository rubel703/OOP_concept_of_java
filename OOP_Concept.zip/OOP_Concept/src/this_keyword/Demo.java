/*
 
 *"this" keyword used to refer current class object.
 *using current class instance variable.
 1.refer current class instance variable.
 2.it can be used to call current class constructor.
 3.it can be to call current class method.
 4.it can be passed as an arguments in the method(event handling)
 
 */