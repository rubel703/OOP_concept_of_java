package this_keyword;

public class Test_person {

	public static void main(String[] args) {
		Person p1 = new Person("Hossain", 21);
		p1.display();

		Person p2 = new Person("Rubel", 23, "black");
		p2.display();

	}

}
