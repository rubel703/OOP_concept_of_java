package overriding_method;

public class Teacher extends Person {
	
	String varsityname;
	//@overriding method
	void displayinformation() {
		System.out.println("My name is:"+name);
		System.out.println("My age:"+age);
		System.out.println("My qualification:"+qualification);
		System.out.println("My university name:"+varsityname);
	}

	public static void main(String[] args) {
		Teacher t1=new Teacher();
		t1.name="Arafat Hossain";
		t1.age=20;
		t1.qualification="Bsc in EEE";
		t1.varsityname="North South University";
		t1.displayinformation();

	}

}
