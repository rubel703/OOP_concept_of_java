package overriding_method;

public class Person {
	String name,qualification;
	int age;
	
	void displayInformation()
	//static displayInformation()
	//final displayInformation()
	{
		System.out.println("My name is:"+name);
		System.out.println("My age:"+age);
		System.out.println("My qualification:"+qualification);
	}

}
