package supper_keyword;

public class Y extends X {
	int a = 10;

	void disInfo() {
		System.out.println(super.a);
		//System.out.println(a);
	}
	
	
	public static void main(String[]args) {
		Y y1=new Y();
		y1.disInfo();
	}

}
