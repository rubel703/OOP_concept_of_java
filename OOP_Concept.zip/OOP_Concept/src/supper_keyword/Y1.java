package supper_keyword;

public class Y1 extends X1 {
	// @override
	void display() {
		super.display();
		System.out.println("I am Sub-Class");
	}

	public static void main(String[] args) {
		Y1 m = new Y1();
		m.display();

	}

}
