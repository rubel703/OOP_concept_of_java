package supper_keyword;

public class Vehicle {
	String color; // instance variable
	double weight;

	Vehicle(String c, double w) { // constructor
		color = c; // local variable
		weight = w;
	}

	void attribute() {
		System.out.println("Color:" + color);
		System.out.println("Weight:" + weight);
	}

}
