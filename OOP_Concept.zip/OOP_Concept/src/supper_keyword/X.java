// practice of point number one.
// 1.it is used to call super class instance variable.

package supper_keyword;

public class X {
	int a = 20;

}
