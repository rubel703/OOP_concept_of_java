// practice of point number three.
//3.it is used to call super class constructor.

package supper_keyword;

public class X2 {
	X2(){
		System.out.println("X2 is constructor");
	}

}
