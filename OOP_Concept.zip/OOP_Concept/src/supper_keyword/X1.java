// practice of point number two.
//2.it is used to call super class method.(override method)

package supper_keyword;

public class X1 {
	void display() {
		System.out.println("I am Super class.");
	}

}
