package supper_keyword;

public class Y2 extends X2 {
	Y2(){
		super();
		System.out.println("Y2 is constructor");
	}

	public static void main(String[] args) {
		Y2 y=new Y2();
		//X2 x=new X2();

	}

}
