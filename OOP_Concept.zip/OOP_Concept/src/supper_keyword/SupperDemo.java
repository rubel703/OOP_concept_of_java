/*
 "Super" keyword is used to refer immediate super class object.
 Usage of super keyword.....
 1.it is used to call super class instance variable 
 2.it is used to call super class method.(override method)
 3.it is used to call super class constructor.
 */
