package supper_keyword;

public class Car extends Vehicle {
	int gear; // instance variable

	Car(String c, double w, int g) { // again constructor
		super(c, w); // super class constructor called
		gear = g;
	}
	void arttibute() { // overriding method
		/*System.out.println("Color:" + color);
		System.out.println("Weight:" + weight);*/
		super.attribute();
		System.out.println("Gear:" + gear);
	}
	
	public static void main(String[]args) {
		Car myCar=new Car("Blue", 250, 60);
		myCar.arttibute();
	}

}
